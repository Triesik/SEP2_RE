package view.user.mainUser;

public interface mainUserView {
    public void closeWindow();
}
