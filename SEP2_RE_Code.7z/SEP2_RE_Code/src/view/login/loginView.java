package view.login;

public interface loginView {

    public String getCPR();
    public String getPassword();
    public void clearInput();
    public void closeWindow();
    public void hideWindow();
}
