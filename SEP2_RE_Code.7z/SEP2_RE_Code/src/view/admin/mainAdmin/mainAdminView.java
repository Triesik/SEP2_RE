package view.admin.mainAdmin;

public interface mainAdminView {
    public void closeWindow();
}
