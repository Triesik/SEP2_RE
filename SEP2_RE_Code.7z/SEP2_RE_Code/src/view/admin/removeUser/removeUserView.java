package view.admin.removeUser;

public interface removeUserView {

    public String getCPR();

    public void clearInput();
}
