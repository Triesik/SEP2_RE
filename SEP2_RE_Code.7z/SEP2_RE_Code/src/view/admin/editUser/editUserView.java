package view.admin.editUser;

public interface editUserView {

    public String getCPR();
    public String getFirstName();
    public String getLastName();
    public String getMobileNumber();
    public String getEmail();
    public String getPassword();

}
