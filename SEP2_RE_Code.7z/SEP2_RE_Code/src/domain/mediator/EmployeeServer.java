package domain.mediator;

public class EmployeeServer {
}
