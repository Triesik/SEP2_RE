package domain.model;
import java.util.Date;


public class EmployeesFactory {
	public static Employee create(int cprNumber, String firstName, String lastName, String mobileNumber,
			String email,  String password) {
		Employee employee = null;

		
		return employee;

	}


}
